package com.namanpay.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF151922)
private val Muted = Color(0xFF9AA3B2)
private val Accent = Color(0xFFB9F36A)

class MainActivity : ComponentActivity() {
    private var unlocked by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg, surface = Panel, primary = Accent,
                    onPrimary = Color(0xFF10140A), onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                if (unlocked) HomeScreen() else LockScreen(
                    onUnlock = { authenticate() }
                )
            }
        }
        authenticate()
    }

    private fun authenticate() {
        val manager = BiometricManager.from(this)
        val canAuth = manager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            // Prototype fallback: keep the app locked if secure device auth is unavailable.
            unlocked = false
            return
        }
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    unlocked = true
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Naman Pay")
            .setSubtitle("Authenticate to access your personal payment launcher")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            ).build()
        prompt.authenticate(info)
    }
}

@Composable
private fun LockScreen(onUnlock: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Lock, null, tint = Accent, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(18.dp))
        Text("NAMAN PAY", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Color.White)
        Spacer(Modifier.height(8.dp))
        Text("Private access only", color = Muted)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onUnlock, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            Text("Unlock with device security")
        }
        Spacer(Modifier.height(12.dp))
        Text("Secure device authentication must be enabled.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun HomeScreen() {
    var upiId by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("Personal payment") }
    var showInfo by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Accent, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Bolt, null, tint = Bg)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("NAMAN PAY", fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("PERSONAL PAYMENT LAUNCHER", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
            }
            Icon(Icons.Default.Lock, null, tint = Accent)
        }
        Spacer(Modifier.height(28.dp))
        Text("Your money.\nYour control.", fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Prepare a payment and continue in an installed UPI app.", color = Muted)
        Spacer(Modifier.height(24.dp))

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("SEND TO UPI ID", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                OutlinedField(value = upiId, onValue = { upiId = it }, hint = "name@bank")
                Spacer(Modifier.height(16.dp))
                Text("AMOUNT (₹)", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                OutlinedField(value = amount, onValue = { amount = it }, hint = "0.00")
                Spacer(Modifier.height(16.dp))
                Text("NOTE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                OutlinedField(value = note, onValue = { note = it }, hint = "Optional")
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        val cleanId = upiId.trim()
                        val value = amount.toBigDecimalOrNull()
                        if (cleanId.contains("@") && value != null && value > java.math.BigDecimal.ZERO) {
                            // Explicit user handoff only. No PIN, bank credentials, or payment result is handled here.
                            val uri = Uri.Builder().scheme("upi").authority("pay")
                                .appendQueryParameter("pa", cleanId)
                                .appendQueryParameter("pn", "Payee")
                                .appendQueryParameter("am", value.toPlainString())
                                .appendQueryParameter("cu", "INR")
                                .appendQueryParameter("tn", note.take(80))
                                .build()
                            val intent = Intent(Intent.ACTION_VIEW, uri)
                            try { context.startActivity(Intent.createChooser(intent, "Continue with UPI app")) }
                            catch (_: Exception) { showInfo = true }
                        } else showInfo = true
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Send, null)
                    Spacer(Modifier.width(8.dp))
                    Text("CONTINUE TO UPI APP", fontWeight = FontWeight.Bold)
                }
                Text(
                    "Review recipient and amount in your UPI app before approving.",
                    color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp)
                )
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SmallTile("QR scan", Icons.Default.QrCodeScanner) { showInfo = true }
            SmallTile("Activity", Icons.Default.History) { showInfo = true }
        }
        Spacer(Modifier.weight(1f))
        Text("PROTOTYPE • NO BANK LINK • NO PIN STORAGE", color = Muted, fontSize = 10.sp)
    }
    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text("Prototype information") },
            text = { Text("This build is a private UI prototype. QR scanning, verified payment status, and bank balance are not connected. Use an installed UPI app for any payment authorization.") },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("OK") } },
            containerColor = Panel
        )
    }
}

@Composable
private fun OutlinedField(value: String, onValue: (String) -> Unit, hint: String) {
    BasicTextField(
        value = value, onValueChange = onValue,
        singleLine = true,
        modifier = Modifier.fillMaxWidth().background(Color(0xFF0D1118), RoundedCornerShape(12.dp)).padding(15.dp),
        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 16.sp),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) Text(hint, color = Muted)
                inner()
            }
        }
    )
}

@Composable
private fun SmallTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.weight(1f).background(Panel, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Accent)
        Spacer(Modifier.width(8.dp))
        Text(title, fontWeight = FontWeight.SemiBold)
    }
}
