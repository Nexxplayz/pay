# Naman Pay – Android prototype

A private, dark-themed Android payment-launcher prototype.

## What this prototype does
- Requires Android device authentication (strong biometric or device credential).
- Lets the user enter a UPI ID, amount, and note.
- Builds a UPI payment URI and explicitly hands it to an installed UPI app using Android's chooser.
- Does **not** collect or store a UPI PIN, bank password, OTP, or card data.
- Does **not** claim a payment succeeded or fetch a bank balance.

## Important limitations
This is a prototype, not a bank-connected or independently certified UPI app.
UPI intent behavior and eligibility depend on the receiving UPI app, payment use case, bank, and applicable NPCI rules. A generic intent is not a guarantee that person-to-person payment initiation will be accepted by every app. Confirm current integration terms with the relevant bank/provider before production use.

QR scanning, verified payment status, transaction history, bank account linking, and balance fetch are not implemented. Do not add PIN collection or attempt to bypass the bank's authorization screen.

## Build
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync and install the Android SDK 35 if prompted.
4. Run the `app` configuration on an Android device with secure screen lock enabled.

## Privacy model
- No backend, analytics, account system, or network permission is included.
- Android backup is disabled.
- Device authentication gates the app UI. This is a device-level access control, not proof of legal identity; anyone who knows the device credential may be able to unlock it.
